<button id="myBtn">More Info</button>
element.addEventListener("click", More Info);

function More Info() {
  alert("More information on the headphones");
}
<button id="myBtn">Location</button>
element.addEventListener("mouseover", Location);

function Location() {
  alert("8233 10Ave Brooklyn 3424 NY");
  element.addEventListener("mouseout", BroadcastChannel);
}